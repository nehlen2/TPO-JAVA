

/**
  SAYEH Nahlane GHina
     **/
package exo2;

import java.util.Scanner;



public class Exo2 {

    
    public static void main(String[] args) {
        // Declaration des variables
       int nb;
       int result;
       int ind;
       result = 0;
       ind = 1;
       
       Scanner sc = new Scanner(System.in);
       System.out.println("\n Entrer le nombre :");
       nb=sc.nextInt(); // On demande a sc de donner le prochain entier
        

        while (ind <= nb) {
            result = result + ind;
            ind++;
        }

        // Affichage du resultat
        System.out.println();
        System.out.println("La somme des " + nb + " entiers est : " + result);
    }
    
    
}
