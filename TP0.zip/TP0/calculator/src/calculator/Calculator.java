
/*
SAYEH Nahlane Ghina BDML3
*/
package calculator;

import java.util.Scanner;

public class Calculator {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        // Exercice 2 : Affichage du menu
        System.out.print("Please enter the operator:\n"
                + "1) add\n"
                + "2) substract\n"
                + "3) multiply\n"
                + "4) divide\n"
                + "5) modulo\n");

        // Exercice 3 : Recuperation de l'operateur
        int operateur;
        operateur = sc.nextInt();

        // Exercice 4 : Premier nombre
        int operande1;
        System.out.println("Please enter the first number:");
        operande1 = sc.nextInt();

        // Exercice 5 : Deuxieme nombre
        int operande2;
        System.out.println("Please enter the second number:");
        operande2 = sc.nextInt();

        // Exercice 6 et 7 : Calcul et verification
        int resultat;

        switch (operateur) {

            case 1:
                resultat = operande1 + operande2;
                System.out.println("The result is : " + resultat);
                break;

            case 2:
                resultat = operande1 - operande2;
                System.out.println("The result is : " + resultat);
                break;

            case 3:
                resultat = operande1 * operande2;
                System.out.println("The result is : " + resultat);
                break;

            case 4:
                resultat = operande1 / operande2;
                System.out.println("The result is : " + resultat);
                break;

            case 5:
                resultat = operande1 % operande2;
                System.out.println("The result is : " + resultat);
                break;

            default:
                System.out.println("Error: Invalid operator!");
                break;
        }

    }
}
